/** ===========================================================================
 * Program : ApplicationConfig.java
 * Function: The implematation of the rental services
 * @author : Bill Huang
 * Date    : Dec 29, 2019
 ** ========================================================================= */
